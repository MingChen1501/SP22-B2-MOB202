package com.example.giaodien.demo1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.example.giaodien.R;
public class Demo14Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo14_main2);
    }
}
