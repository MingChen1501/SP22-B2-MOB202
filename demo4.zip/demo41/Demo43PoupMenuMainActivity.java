package com.example.giaodien.demo41;

import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;

public class Demo43PoupMenuMainActivity extends AppCompatActivity {
    //B1. Tạo menu
    //B2: Ánh xạ menu
    //b3: Xử lý sự kiện
    Button button;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo43_poup_menu_main);
        button= findViewById(R.id.demo43Btn);
        textView = findViewById(R.id.demo43Tv);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //B2. Anh xa
                //PopupMenu(activity,noiHienThiPopup);
                PopupMenu popupMenu = new PopupMenu(Demo43PoupMenuMainActivity.this,textView);//noi hien thi popup
                MenuInflater inflater = (MenuInflater)popupMenu.getMenuInflater();//gan XML voi menu
                inflater.inflate(R.menu.demo42_optionmenu,popupMenu.getMenu());//render menu (ket xuat hinh anh menu)
                popupMenu.show();//hien thi menu
                //b3. Xu ly su kien
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        if(menuItem.getItemId()==R.id.demo42_option_menu1)
                        {
                            Toast.makeText(getApplicationContext(),menuItem.getTitle().toString(),Toast.LENGTH_LONG).show();
                        }
                        else if(menuItem.getItemId()==R.id.demo42_option_menu2)
                        {
                            Toast.makeText(getApplicationContext(),menuItem.getTitle().toString(),Toast.LENGTH_LONG).show();
                        }
                        else if(menuItem.getItemId()==R.id.demo42_option_menu3)
                        {
                            Toast.makeText(getApplicationContext(),menuItem.getTitle().toString(),Toast.LENGTH_LONG).show();
                        }
                        return false;
                    }
                });
            }
        });
    }
}
