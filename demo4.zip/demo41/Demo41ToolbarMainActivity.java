package com.example.giaodien.demo41;

import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;

public class Demo41ToolbarMainActivity extends AppCompatActivity {
    //Muốn chạy được toolbar tự thiết kế thì cần cấu hình trong style.xml dòng sau
    //<style name="AppTheme" parent="Theme.AppCompat.Light.NoActionBar">
    //Muốn chạy Toolbar mặc định của android thì cần sửa trong style.xml dòng sau
    //<style name="AppTheme" parent="Theme.AppCompat.Light.DarkActionBar">
    Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_toolbar_main);
        toolbar = findViewById(R.id.demo41toolbar2);
        toolbar.setNavigationIcon(R.drawable.side_nav_bar);//them buton cho toolbar
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

    }
}
