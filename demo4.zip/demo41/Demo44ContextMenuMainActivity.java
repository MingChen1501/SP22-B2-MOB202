package com.example.giaodien.demo41;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;

public class Demo44ContextMenuMainActivity extends AppCompatActivity {
    //B1 - Tao menu
    //B2 - Tạo ngữ cảnh
    //B3 - Xu ly su kien
    String[] data = new String[]{"Cam","Xoai","Oi","Dua hau","Huong Duong"};
    ArrayAdapter<String> arrayAdapter;
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo44_context_menu_main);
        listView = findViewById(R.id.demo44Listview);
        arrayAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,data);
        listView.setAdapter(arrayAdapter);
        registerForContextMenu(listView);//dang ky context menu cho listview
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.demo44_contextmenu,menu);//gan XML voi menu trong java
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info
                =(AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
        int i = info.position;//vi tri item tren menu
        if(item.getItemId() == R.id.demo44_context_menu1)
        {
            Toast.makeText(this,data[i]+": "+item.getTitle().toString(),Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId() == R.id.demo44_context_menu2)
        {
            Toast.makeText(this,data[i]+": "+item.getTitle().toString(),Toast.LENGTH_LONG).show();
        }
        return super.onContextItemSelected(item);
    }
}
