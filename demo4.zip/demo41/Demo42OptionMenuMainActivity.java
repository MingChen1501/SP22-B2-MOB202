package com.example.giaodien.demo41;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;
public class Demo42OptionMenuMainActivity extends AppCompatActivity {
    //B1 - Tạo menu
    //B2 - Ánh xạ menu
    //B3 - Xử lý sự kiện với menu
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo42_option_menu_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.demo42_optionmenu,menu);//anh xa menu
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //xu ly su kien voi menu
        if(item.getItemId()==R.id.demo42_option_menu1)
        {
            Toast.makeText(this,item.getTitle().toString(), Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId()==R.id.demo42_option_menu2)
        {
            Toast.makeText(this,item.getTitle().toString(), Toast.LENGTH_LONG).show();
        }
        else if(item.getItemId()==R.id.demo42_option_menu3)
        {
            Toast.makeText(this,item.getTitle().toString(), Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);

    }
}
