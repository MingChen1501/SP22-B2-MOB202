package com.example.giaodien.demo41;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;

public class Demo40MainActivity extends AppCompatActivity {
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo40_main);
        button = findViewById(R.id.demo40Btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Demo40MainActivity.this,Demo41ToolbarMainActivity.class);
                startActivity(intent);
            }
        });

    }
}
