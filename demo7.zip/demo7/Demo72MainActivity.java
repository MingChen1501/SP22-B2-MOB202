package com.example.giaodien.demo7;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;
import com.google.android.material.textfield.TextInputLayout;

public class Demo72MainActivity extends AppCompatActivity {
    Button button;
    TextInputLayout textInputLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo72_main);
        button = findViewById(R.id.demo72Btn);
        textInputLayout = findViewById(R.id.demo72TextInputLayout1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(textInputLayout.getEditText().length()==0)
                {
                    textInputLayout.setError("Vui long khong de trong");
                }
                else
                {
                    textInputLayout.setError("");
                }
            }
        });
    }
}
