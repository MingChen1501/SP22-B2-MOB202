package com.example.giaodien.demo7;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;
import com.google.android.material.textfield.TextInputLayout;

public class Demo76MainActivity extends AppCompatActivity {
    TextInputLayout textInputLayout;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo76_main);
        textInputLayout = findViewById(R.id.demo76TextInputLayout2);
        button = findViewById(R.id.demo76BtnLogin);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!validateEmail(textInputLayout.getEditText().getText()))
                {
                    textInputLayout.setError("Khong dung dinh dang email");
                }
                else
                {
                    textInputLayout.setError("");
                }
            }
        });
    }
    public boolean validateEmail(CharSequence e)
    {
        return !TextUtils.isEmpty(e)&& Patterns.EMAIL_ADDRESS.matcher(e).matches();
    }
}
