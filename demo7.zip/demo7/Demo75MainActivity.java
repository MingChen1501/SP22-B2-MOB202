package com.example.giaodien.demo7;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;

public class Demo75MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo75_main);
    }
}
