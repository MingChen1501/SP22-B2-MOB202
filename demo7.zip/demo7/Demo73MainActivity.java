package com.example.giaodien.demo7;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class Demo73MainActivity extends AppCompatActivity {
    FloatingActionButton floatingActionButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo73_main);
        floatingActionButton = findViewById(R.id.frmo73floatingActionButton);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Ban vua click floating",
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}
