package com.example.giaodien.demo6;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.example.giaodien.R;

public class Demo61MainActivity extends AppCompatActivity {
    Button btnAc;
    EditText txtAc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo61_main);
        btnAc = findViewById(R.id.demo61_Activity_Btn1);
        txtAc = findViewById(R.id.demo61_activity_txt1);
        btnAc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //tạo đối tượng quản lý fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                //ánh xạ fragment
                Demo61BlankFragment fragment =
                        (Demo61BlankFragment)fragmentManager.findFragmentById(R.id.demo61_fragment);
                //Chuyển text từ activity sang fragment
                fragment.txtS.setText(txtAc.getText().toString());
            }
        });

    }
}
