package com.example.giaodien.demo6;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class AdapterFrm extends FragmentPagerAdapter {
    private final List<Fragment> fragmentList = new ArrayList<>();//list fragment
    private final List<String> fragmentTitle = new ArrayList<>();//list tieu de
    public AdapterFrm(FragmentManager fm)
    {
        super(fm);
    }
    @NonNull
    @Override
    public Fragment getItem(int position) {
        return fragmentList.get(position);
    }

    @Override
    public int getCount() {
        return fragmentList.size();
    }

    //lay tieu de Tab
    @Override
    public CharSequence getPageTitle(int position) {
        return fragmentTitle.get(position);
    }
    //ham them fragment
    public void addFrag(Fragment fragment,String title)
    {
        fragmentList.add(fragment);
        fragmentTitle.add(title);
    }
}
