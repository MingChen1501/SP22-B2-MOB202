package com.example.giaodien.demo6;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.example.giaodien.R;

public class Demo62MainActivity extends AppCompatActivity {
    //ẩn, hiện fragment
    Button button;
    Button btnShow;
    Demo62BlankFragment1 frm1;
    Demo62BlankFragment2 frm2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo62_main);
        button = findViewById(R.id.demo62_activity_btn1);
        btnShow = findViewById(R.id.demo62_activity_btn2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //tao doi tuong quan ly fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                //anh xa fragment
                frm1=(Demo62BlankFragment1)fragmentManager.findFragmentById(R.id.demo62fragment1);
                frm2=(Demo62BlankFragment2)fragmentManager.findFragmentById(R.id.demo62_fragment2);
                //thao tac voi fragment

                fragmentManager.beginTransaction()
                        .hide(frm1)
                        //.show(frm2)
                        .commit();

                btnShow.setVisibility(View.VISIBLE);
            }
        });
        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //tao doi tuong quan ly fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                //anh xa fragment
                frm1=(Demo62BlankFragment1)fragmentManager.findFragmentById(R.id.demo62fragment1);
                frm2=(Demo62BlankFragment2)fragmentManager.findFragmentById(R.id.demo62_fragment2);
                //thao tac voi fragment
                fragmentManager.beginTransaction()
                        //.hide(frm1)
                        .show(frm1)
                        .commit();
            }
        });
    }
}
