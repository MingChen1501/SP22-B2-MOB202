package com.example.giaodien.demo6;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.giaodien.R;

public class Demo61BlankFragment extends Fragment {
    //Truyen du lieu tu activity vao fragment
    Button btnSend;
    EditText txtS;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_demo61_blank, container, false);
        //---
        btnSend = view.findViewById(R.id.demo61_frag1_btn1);
        txtS = view.findViewById(R.id.demo61_frm1_Txt1);
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getContext(),"Da gui text: "+txtS.getText(),Toast.LENGTH_LONG).show();
            }
        });
        //--
        return view;
    }
}
