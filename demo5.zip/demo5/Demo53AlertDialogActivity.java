package com.example.giaodien.demo5;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;

public class Demo53AlertDialogActivity extends AppCompatActivity {
    Button btn1, btn2, btn3, btn4;
    Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo53_alert_dialog);
        btn1 = findViewById(R.id.demo53Btn1);
        btn2 = findViewById(R.id.demo53Btn2);
        btn3 = findViewById(R.id.demo53Btn3);
        btn4 = findViewById(R.id.demo53Btn4);

        //dialog thong bao
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);//tao builder
                builder.setMessage("Noi dung message");//them noi dung
                builder.setTitle("Title");//them tieu de
                //xu ly su kien ok
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),"Ban chon OK",Toast.LENGTH_LONG).show();
                        //dialog.dismiss();
                    }
                });
                //xu ly su kien cancel
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),"Ban chon Cancel",Toast.LENGTH_LONG).show();
                    }
                });
                AlertDialog dialog = builder.create();//tao dialog
                dialog.show();//hien thi dialog
            }
        });
        //------
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String[] color = getResources().getStringArray(R.array.color);//doc mang tu String..xml
                AlertDialog.Builder builder = new AlertDialog.Builder(context)
                        .setTitle("Them tieu de")
                        .setSingleChoiceItems(color, 1, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                Toast.makeText(getApplicationContext(),color[i].toString(),Toast.LENGTH_LONG).show();

                            }
                        });
                AlertDialog alertDialog = builder.create();//tao dialog tu buider
                alertDialog.show();//hien thi
            }
        });
        //------
        btn3.setOnClickListener(new View.OnClickListener() {
            final String[] color = getResources().getStringArray(R.array.color);//doc mang tu String..xml
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context)
                        .setTitle("Title")
                        .setMultiChoiceItems(color, null, new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i, boolean b) {
                                Toast.makeText(getApplicationContext(),color[i].toString(),Toast.LENGTH_LONG).show();
                            }
                        });
                AlertDialog alertDialog2 = builder.create();
                alertDialog2.show();
            }
        });
        //---login
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("title cua dialog");
                ///
                LayoutInflater inflater = getLayoutInflater();//ham ket xuat layout
                View view1 = inflater.inflate(R.layout.item_demo54_login,null);
                builder.setView(view1);//ket xuat view
                //anh xa
                final EditText txtUser = (EditText)view1.findViewById(R.id.demo54TxtUser);
                final EditText txtPass = (EditText)view1.findViewById(R.id.demo54TxtPass);
                //them button ok
                builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(getApplicationContext(),"Chao: "+txtUser.getText(),Toast.LENGTH_LONG).show();
                    }
                });
                //tao dialog
                AlertDialog alertDialog4 = builder.create();//tao dialog
                alertDialog4.show();//hien thi
            }
        });
    }
}

















