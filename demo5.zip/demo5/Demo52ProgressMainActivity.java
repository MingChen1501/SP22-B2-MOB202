package com.example.giaodien.demo5;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;

public class Demo52ProgressMainActivity extends AppCompatActivity {
    Button btn1, btn2;
    ProgressBar progressBar;
    ProgressDialog progressDialog;
    Handler handler = new Handler();
    Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo52_progress_main);
        btn1 = findViewById(R.id.demo52Btn1);
        btn2 = findViewById(R.id.demo52Btn2);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressDialog = new ProgressDialog(context);//tao moi thanh tien trinh
                progressDialog.setTitle("Downloading....");//set tieu de
                progressDialog.setMessage("Download in processing....");//set noi dung
                progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);//dinh dang
                progressDialog.setProgress(0);//diem dau
                progressDialog.setMax(100);//diem cuoi
                progressDialog.show();//hien thi (khong bao gio mat)
                //xu ly tien trinh
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        //trong khi thanh tien trinh chua chay du 100%
                        while (progressDialog.getProgress()<=progressDialog.getMax())
                        {
                            try {
                                Thread.sleep(1000);//nghi 1 giay
                                handler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        progressDialog.incrementProgressBy(5);//buoc nhay la 5%
                                    }
                                });
                                //neu da chay du 100%
                                if(progressDialog.getProgress()==progressDialog.getMax())
                                {
                                    progressDialog.dismiss();//tat dialog
                                }
                            }
                            catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }

                    }
                }).start();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final  ProgressDialog progressDialog1
                        =ProgressDialog.show(context,"Please wait...",
                        "Downloading...",
                        true);
                progressDialog1.setCancelable(true);//co button cancel
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });
    }
}
