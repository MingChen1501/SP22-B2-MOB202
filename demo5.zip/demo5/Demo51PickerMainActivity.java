package com.example.giaodien.demo5;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;

import com.example.giaodien.R;

import java.util.Calendar;

public class Demo51PickerMainActivity extends AppCompatActivity {
    Button btnDate,btnTime;
    TextView txtTime, txtDate;
    Context context = this;
    Calendar calendar =Calendar.getInstance();
    final  int hour = calendar.get(calendar.HOUR_OF_DAY);
    final int minute1 = calendar.get(calendar.MINUTE);
    DatePickerDialog dp;
    TimePickerDialog tp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo51_picker_main);
        btnDate = findViewById(R.id.demo51BtnDate);
        btnTime = findViewById(R.id.demo51BtnTime);
        txtDate = findViewById(R.id.demo51TxtDate);
        txtTime = findViewById(R.id.demo51TxtTime);
        btnTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tp=new TimePickerDialog(context, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
                        txtTime.setText(hourOfDay+" : "+minute);
                    }
                },hour,minute1,
                        android.text.format.DateFormat.is24HourFormat(context));
                tp.show();
            }
        });
        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar c = Calendar.getInstance();
                int day = c.get(Calendar.DAY_OF_MONTH);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);
                dp = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year1, int month1, int day1) {
                        month1 = month1+1;
                        txtDate.setText(day1+"/"+month1+"/"+year1);
                    }
                },day,month,year);
                dp.show();
            }
        });
    }
}
