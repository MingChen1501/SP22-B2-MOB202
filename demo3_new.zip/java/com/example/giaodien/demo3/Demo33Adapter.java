package com.example.giaodien.demo3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.example.giaodien.R;

public class Demo33Adapter extends BaseAdapter {
    Context context;
    int hinh[];
    LayoutInflater layoutInflater;
    public Demo33Adapter(Context context, int[] hinh)
    {
        this.context = context;
        this.hinh = hinh;
        layoutInflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return hinh.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = layoutInflater.inflate(R.layout.item_demo33,null);
        ImageView imageView = (ImageView)view.findViewById(R.id.demo33_item_hinh);
        imageView.setImageResource(hinh[i]);
        return view;
    }
}
