package com.example.giaodien.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.giaodien.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Demo32MainActivity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main);
        listView = findViewById(R.id.demo32Listview);
        //b1 - Tao items layout
        //b2 - Tao nguon du lieu
        List<HashMap<String,Object>> list = new ArrayList<>();

        HashMap<String,Object> hm = new HashMap<>();
        hm.put("ten","Hung");
        hm.put("tuoi",18);
        hm.put("hinh",R.drawable.android);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("ten","An");
        hm.put("tuoi",19);
        hm.put("hinh",R.drawable.microsoft);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("ten","Binh");
        hm.put("tuoi",20);
        hm.put("hinh",R.drawable.facebook);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("ten","Cuong");
        hm.put("tuoi",21);
        hm.put("hinh",R.drawable.firefox);
        list.add(hm);

        hm = new HashMap<>();
        hm.put("ten","Dung");
        hm.put("tuoi",22);
        hm.put("hinh",R.drawable.facebook);
        list.add(hm);
        //b3 - Anh xa nguon du lieu
        String[] from = {"ten","tuoi","hinh"};
        int[] to= {R.id.demo32_item_ten,R.id.demo32_item_tuoi,R.id.demo32_item_hinh};
        //B4 - Tao simpleAdaper
        SimpleAdapter simpleAdapter
                =new SimpleAdapter(this,list,R.layout.item_demo32,from,to);
        //b5. Dua du lieu len listview
        listView.setAdapter(simpleAdapter);
    }
}
