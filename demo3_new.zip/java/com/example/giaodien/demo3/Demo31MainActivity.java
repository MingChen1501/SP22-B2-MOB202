package com.example.giaodien.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import com.example.giaodien.R;
public class Demo31MainActivity extends AppCompatActivity {
    ListView listView;
    Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo31_main);
        listView = findViewById(R.id.demo31Listview);
        spinner = findViewById(R.id.demo31Spinner);
        //B1. Tao nguon du lieu
        String[] items = {"Lop 1","Lop 2","Lop 3","Lop 4","Lop 5"};
        //B2. Tao Adapter
        ArrayAdapter<String> listViewAdapter
                =new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,items);
        //B3. Dua du lieu len Listview qua Adapter
        listView.setAdapter(listViewAdapter);
        ///////------------------------
        ArrayAdapter<String> spinnerAdaper
                =new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);
        spinner.setAdapter(spinnerAdaper);
    }
}
