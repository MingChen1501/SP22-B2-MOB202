package com.example.giaodien.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.giaodien.R;
public class Demo34MainActivity extends AppCompatActivity {
    ListView listView;
    //b1 - Tao nguon du lieu
    String[] lsTen = {"Android","Ios","WindowPhone","Symbian"};
    int[] lsHinh = {R.drawable.android,R.drawable.apple,R.drawable.microsoft,R.drawable.facebook};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo34_main);
        listView = findViewById(R.id.demo34Listview);
        //goi adapter
        CustomAdapter adapter = new CustomAdapter();
        listView.setAdapter(adapter);
    }
    //B2 - Tao lop anh xa item_bai34
    public class ViewAnhXa{
        public ImageView img_hinh;
        public TextView tv_ten;
    }
    //b3 - Tao view- anh xa - lay du lieu
    public class CustomAdapter extends BaseAdapter{
        //Lay ve so luong item
        @Override
        public int getCount() {//bat buoc
            return lsHinh.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }
        //tao view - anh xa - lay du lieu
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {//bat buoc
            ViewAnhXa vax;
            if(view==null)//neu chua ton tai view -> can tao moi
            {
                vax = new ViewAnhXa();
                //goi doi tuong render layout
                LayoutInflater layoutInflater = getLayoutInflater();
                //render layout
                view=layoutInflater.inflate(R.layout.item_demo34,null);
                //anh xa tung phan
                vax.tv_ten = (TextView)view.findViewById(R.id.demo34_item_ten);
                vax.img_hinh = (ImageView)view.findViewById(R.id.demo34_item_hinh);
                //tao template de lan sau su dung
                view.setTag(vax);
            }
            else //neu da ton tai view -> lay view ra dung
            {
                vax = (ViewAnhXa)view.getTag();//lay template co san ra dung
            }
            //thuc hien cap nhat du lieu
            vax.img_hinh.setImageResource(lsHinh[i]);
            vax.tv_ten.setText(lsTen[i]);
            return view;
        }
    }
}
