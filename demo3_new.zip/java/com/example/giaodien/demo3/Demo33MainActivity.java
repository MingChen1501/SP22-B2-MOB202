package com.example.giaodien.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.GridView;

import com.example.giaodien.R;
public class Demo33MainActivity extends AppCompatActivity {
    GridView gridView;
    int[] hinh={
         R.drawable.facebook,
         R.drawable.microsoft,
         R.drawable.apple,
         R.drawable.android,
         R.drawable.kimnamjoo,
         R.drawable.blogger,
         R.drawable.chrome,
         R.drawable.dell,
         R.drawable.firefox
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo33_main);
        gridView = findViewById(R.id.demo33Gridview);
        Demo33Adapter adapter = new Demo33Adapter(getApplicationContext(),hinh);
        gridView.setAdapter(adapter);

    }
}
