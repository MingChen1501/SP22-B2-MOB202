package com.example.giaodien.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.giaodien.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Demo32Main2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main2);
        listView = findViewById(R.id.demo32Listview);
        //B1- Tạo listview và item
        //B2 - Tạo nguồn dữ liệu
        List<HashMap<String,Object>> ds = new ArrayList<>();
        HashMap<String,Object> hm = new HashMap<>();
        hm.put("ten","Nguyen Van A");
        hm.put("tuoi",18);
        hm.put("hinh",R.drawable.facebook);
        ds.add(hm);

        hm = new HashMap<>();
        hm.put("ten","Tran Van B");
        hm.put("tuoi",20);
        hm.put("hinh",R.drawable.chrome);
        ds.add(hm);

        hm = new HashMap<>();
        hm.put("ten","Vu Van C");
        hm.put("tuoi",22);
        hm.put("hinh",R.drawable.firefox);
        ds.add(hm);
        //B3 - định nghĩa from, to
        String[] from = {"ten","tuoi","hinh"};
        int[] to =  {R.id.bai32_item_ten,R.id.bai32_item_tuoi,R.id.bai32_item_hinh};
        //b4: Tạo simpleAdapter(context,Data,Items,From,To)
        SimpleAdapter adapter = new SimpleAdapter(this,ds,R.layout.items_bai32,from,to);
        //b5-Dua du lieu len listview
        listView.setAdapter(adapter);

    }
}
