package com.example.giaodien.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.giaodien.R;
public class Demo31Main2Activity extends AppCompatActivity {
    Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo31_main2);
        spinner = findViewById(R.id.demo31Spinner);
        //B1 - Khai bao Nguon du lieu
        String[] items = {"Lop1","Lop2","Lop3","Lop4"};
        //B2 - Tao moi Adapter
        //gom 3 tham so: ArrayAdapter(context,giaoDienHienThi,nguonDuLieu)
        ArrayAdapter<String> arrayAdapter
         = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,items);
        //b3 - Chuyen du lieu tu nguon du lieu len View
        spinner.setAdapter(arrayAdapter);
    }
}
