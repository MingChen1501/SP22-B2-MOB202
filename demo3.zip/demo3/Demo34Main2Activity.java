package com.example.giaodien.demo3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.giaodien.R;
public class Demo34Main2Activity extends AppCompatActivity {
    ListView listView;
    String[] ten = {"Android","Ios","Windowphone"};
    int[] hinh = {R.drawable.android,R.drawable.apple,R.drawable.kimnamjoo};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo34_main2);
        listView = findViewById(R.id.demo34Listview);

        CustomAdapter customAdapter = new CustomAdapter();
        listView.setAdapter(customAdapter);
    }
    public class CustomAdapter extends BaseAdapter{

        @Override
        public int getCount() {//tong cac item (bat buoc)
            return hinh.length;
        }

        @Override
        public Object getItem(int i) {//lay ve 1 item
            return null;
        }

        @Override
        public long getItemId(int i) {//lay ve id cua item
            return 0;
        }
        //tao layout + lay du lieu cho view
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            //b1- Gan layout va khoi tao 1 o
            View_mot_o mot_o;
            if(view==null)//neu chua ton tai view thi tao view moi
            {
                mot_o = new View_mot_o();//tao view moi
                LayoutInflater layoutInflater = getLayoutInflater();//doi tuong render view
                view = layoutInflater.inflate(R.layout.items_bai34,null);//gan file XML voi view
                //anh xa
                mot_o.img_hinh = (ImageView)view.findViewById(R.id.bai34_item_hinh);//anh xa thanh phan Img
                mot_o.tv_ten = (TextView)view.findViewById(R.id.bai34_item_ten);//anh xa thanh phan TextView
                view.setTag(mot_o);//tao template de lan sau dung
            }
            else //neu da ton tai view thi goi view cu
            {
                mot_o = (View_mot_o)view.getTag();//goi view cu
            }
            //b2 - gan du lieu cho view 1 o
            mot_o.img_hinh.setImageResource(hinh[i]);//gan du lieu cho anh
            mot_o.tv_ten.setText(ten[i]);//gan du lieu cho ten
            return view;
        }
    }
    public class View_mot_o{//class nay gan voi Item_Bai34
        public ImageView img_hinh;
        public TextView tv_ten;
    }
}
